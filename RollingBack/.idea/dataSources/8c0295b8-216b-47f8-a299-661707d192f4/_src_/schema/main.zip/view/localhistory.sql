CREATE VIEW localhistory AS SELECT strftime('%Y-%m-%d %H:%M:%f', transactions.time,'localtime' )AS localtime,transactions.account, transactions.amount FROM transactions ORDER BY transactions.time;
